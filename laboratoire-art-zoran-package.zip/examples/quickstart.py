from lzart.core import LaboratoireArtZoran

lab = LaboratoireArtZoran()
print(lab.ajouter_projet("Oeuvre1"))
print(lab.ajouter_projet("Oeuvre2"))
print(lab.lister_projets())
