class LaboratoireArtZoran:
    def __init__(self):
        self.projets = []
    def ajouter_projet(self, nom):
        self.projets.append(nom)
        return "Projet ajouté"
    def lister_projets(self):
        return self.projets
