from lzart.core import LaboratoireArtZoran

def test_ajouter_projet():
    lab = LaboratoireArtZoran()
    res = lab.ajouter_projet("Oeuvre1")
    assert "ajouté" in res and "Oeuvre1" in lab.projets
